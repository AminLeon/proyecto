const preferencesForm = document.getElementById('preferencesForm');

    preferencesForm.addEventListener('submit', function(event) {
      event.preventDefault();

      const name = document.getElementById('name').value;
      const backgroundColor = document.getElementById('backgroundColor').value;
      const fontColor = document.getElementById('fontColor').value;

      localStorage.setItem('userName', name);
      localStorage.setItem('backgroundColor', backgroundColor);
      localStorage.setItem('fontColor', fontColor);

      window.location.href = 'saludo.html';
    });