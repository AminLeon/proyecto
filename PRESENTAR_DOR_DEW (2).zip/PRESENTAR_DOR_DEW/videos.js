// script.js

const video = document.getElementById('myVideo');

// Función para activar el modo de pantalla completa
function toggleFullScreen() {
  if (!document.fullscreenElement) {
    video.requestFullscreen();
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  }
}

// Función para avanzar 10 segundos
function skipForward() {
    video.currentTime += 10;
}

// Función para retroceder 10 segundos
function skipBackward() {
    video.currentTime -= 10;
}

// Event listener para activar el modo de pantalla completa
video.addEventListener('dblclick', toggleFullScreen);

// Event listeners para avanzar y retroceder
document.getElementById('skipForwardButton').addEventListener('click', skipForward);
document.getElementById('skipBackwardButton').addEventListener('click', skipBackward);

const audio = document.querySelector('audio');

$(document).ready(function() {
  // Al hacer clic en el botón
  $('#scrollButton').click(function() {
    // Hacer un desplazamiento suave hacia arriba
    $('html, body').animate({scrollTop: 0}, 'slow');
  });
});
