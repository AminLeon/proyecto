
    function verificarEdad() {
      const edad = prompt("¿Cuál es tu edad?");

      // Comprobar si la edad es mayor o igual a 18
      if (parseInt(edad) >= 18) {
        alert("¡Eres mayor de 18 años! Pulsa 'Aceptar' para continuar.");
        // Almacenar el dato en IndexedDB
        almacenarEnIndexedDB(true);
      } else {
        alert("Eres menor de 18 años. No puedes continuar.");
        // Almacenar el dato en IndexedDB
        almacenarEnIndexedDB(false);
      }
    }

    function almacenarEnIndexedDB(esMayor) {
      const openRequest = indexedDB.open('edadDB', 1);

      openRequest.onupgradeneeded = function(event) {
        const db = event.target.result;
        const edadStore = db.createObjectStore('edades', { keyPath: 'id', autoIncrement: true });
      };

      openRequest.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction('edades', 'readwrite');
        const edadStore = transaction.objectStore('edades');

        const nuevaEdad = {
          esMayor: esMayor
        };

        const addRequest = edadStore.add(nuevaEdad);

        addRequest.onsuccess = function() {
          console.log('Edad almacenada correctamente en IndexedDB');
        };

        addRequest.onerror = function() {
          console.error('Error al almacenar la edad en IndexedDB');
        };
      };

      openRequest.onerror = function() {
        console.error('Error al abrir la base de datos IndexedDB');
      };
    }

