
const hamburger = document.querySelector('.header .nav-bar .nav-list .hamburger');
const mobile_menu = document.querySelector('.header .nav-bar .nav-list ul');
const menu_item = document.querySelectorAll('.header .nav-bar .nav-list ul li a');
const header = document.querySelector('.header.container');


hamburger.addEventListener('click', () => {
	hamburger.classList.toggle('active');
	mobile_menu.classList.toggle('active');
});

document.addEventListener('scroll', () => {
	var scroll_position = window.scrollY;
	if (scroll_position > 250) {
		header.style.backgroundColor = '#29323c';
	} else {
		header.style.backgroundColor = 'transparent';
	}
});

menu_item.forEach((item) => {
	item.addEventListener('click', () => {
		hamburger.classList.toggle('active');
		mobile_menu.classList.toggle('active');
	});
});


function NavegadorCompatibilidad() {
	this.esCompatible = function() {
	  return !!window;
	};
  
	this.obtenerVersion = function() {
	  if (this.esCompatible()) {
		return window.navigator.appVersion;
	  } else {
		return 'Navegador no compatible con JavaScript';
	  }
	};
  }
  
  const navegador = new NavegadorCompatibilidad();
  

  if (navegador.esCompatible()) {
	console.log('El navegador es compatible con JavaScript');
	console.log('Versión del navegador:', navegador.obtenerVersion());
  } else {
	console.log('El navegador no es compatible con JavaScript');
  }

  console.log (Math.PI-Math.PI);

  var osm = L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png');
  var map = L.map('map', {
		  center: [38.085, -0.946],
		  zoom: 15,
		  layers: osm});
		  
		  					
	 var lc = L.control.locate({
		position: 'topleft',
		strings: {
			title: "Show me where I am!"
		 }}).addTo(map);



  




