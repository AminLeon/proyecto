$(document).ready(function() {
  // Obtener la ubicación del usuario
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showMap);
  } else {
    alert("Geolocalización no es soportada en este navegador.");
  }
});

function showMap(position) {
  var lat = position.coords.latitude;
  var lng = position.coords.longitude;

  // Crear mapa centrado en la ubicación del usuario
  var map = L.map('map').setView([lat, lng], 13);

  // Agregar una capa de mapa base
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);

  // Marcar la ubicación del usuario en el mapa
  L.marker([lat, lng]).addTo(map)
    .bindPopup('Tu ubicación')
    .openPopup();
}
