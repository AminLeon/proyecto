const form = document.getElementById('contactForm');

    // Evento para la validación del formulario cuando se envía
    form.addEventListener('submit', function(event) {
      // Obtener los valores de los campos del formulario
      const firstName = document.getElementById('firstName');
      const lastName = document.getElementById('lastName');
      const gender = document.querySelector('input[name="gender"]:checked');
      const email = document.getElementById('email');
      const password = document.getElementById('password');
      const number = document.getElementById('number');

      // Variable para indicar si el formulario es válido
      let valid = true;

      // Validar el campo de nombre
      if (firstName.value === '') {
        document.getElementById('firstNameError').textContent = 'Por favor ingresa tu nombre.';
        valid = false;
      } else {
        document.getElementById('firstNameError').textContent = '';
      }

      // Validar el campo de apellido
      if (lastName.value === '') {
        document.getElementById('lastNameError').textContent = 'Por favor ingresa tu apellido.';
        valid = false;
      } else {
        document.getElementById('lastNameError').textContent = '';
      }

      // Validar el campo de género
      if (!gender) {
        document.getElementById('genderError').textContent = 'Por favor selecciona tu género.';
        valid = false;
      } else {
        document.getElementById('genderError').textContent = '';
      }

      // Validar el campo de correo electrónico
      if (email.value === '' || !email.value.includes('@') || (!email.value.includes('.com') && !email.value.includes('.es'))) {
        document.getElementById('emailError').textContent = 'Por favor ingresa un correo electrónico válido.';
        valid = false;
      } else {
        document.getElementById('emailError').textContent = '';
      }

      // Validar el campo de contraseña
      if (password.value === '') {
        document.getElementById('passwordError').textContent = 'Por favor ingresa tu contraseña.';
        valid = false;
      } else {
        document.getElementById('passwordError').textContent = '';
      }

      // Validar el campo de número de teléfono
      if (number.value === '') {
        document.getElementById('numberError').textContent = 'Por favor ingresa tu número de teléfono.';
        valid = false;
      } else {
        document.getElementById('numberError').textContent = '';
      }

      // Evitar el envío del formulario si no es válido
      if (!valid) {
        event.preventDefault();
      }
    });