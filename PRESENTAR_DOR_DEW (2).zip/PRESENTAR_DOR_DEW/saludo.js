const userName = localStorage.getItem('userName');
const backgroundColor = localStorage.getItem('backgroundColor');
const fontColor = localStorage.getItem('fontColor');

if (userName && backgroundColor && fontColor) {
  const saludoElement = document.getElementById('saludo');
  saludoElement.innerHTML = `Hola, ${userName}!`;

  document.body.style.backgroundColor = backgroundColor;
  document.body.style.color = fontColor;
} else {
  window.location.href = 'preferencias.html';
}

const deletePreferencesButton = document.getElementById('deletePreferences');
deletePreferencesButton.addEventListener('click', function() {
  localStorage.removeItem('userName');
  localStorage.removeItem('backgroundColor');
  localStorage.removeItem('fontColor');
  window.location.href = 'preferencias.html';
});